﻿

USE master;
GO


IF DB_ID('HastaneOtomasyon') IS NULL
BEGIN
    RAISERROR('Database HastaneOtomasyon yok. Önce oluştur.',16,1);
    RETURN;
END
GO

-- Tek kullanıcı modu
ALTER DATABASE HastaneOtomasyon SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
GO

USE HastaneOtomasyon;
GO



-- Tüm FK'leri drop et
DECLARE @sql NVARCHAR(MAX);
SET @sql = '';
SELECT @sql = @sql + 'ALTER TABLE ' + QUOTENAME(OBJECT_SCHEMA_NAME(f.parent_object_id))
    + '.' + QUOTENAME(OBJECT_NAME(f.parent_object_id)) + ' DROP CONSTRAINT ' + QUOTENAME(f.name) + ';'+CHAR(13)
FROM sys.foreign_keys f
WHERE f.is_ms_shipped = 0;
IF LEN(@sql) > 0 EXEC sp_executesql @sql;
GO

-- SP, View, FN, Trigger ve Log Tablolarını drop et
DECLARE @trig_sql NVARCHAR(MAX) = N'';
SELECT @trig_sql = @trig_sql + 'DROP TRIGGER IF EXISTS ' + QUOTENAME(OBJECT_SCHEMA_NAME(t.object_id))
    + '.' + QUOTENAME(t.name) + ';'+CHAR(13)
FROM sys.triggers t
WHERE is_ms_shipped = 0 AND t.parent_class = 0;
IF LEN(@trig_sql) > 0 EXEC sp_executesql @trig_sql;

-- SP'ler 
IF OBJECT_ID('dbo.SP_RandevuEkleKontrol','P') IS NOT NULL DROP PROCEDURE dbo.SP_RandevuEkleKontrol;
IF OBJECT_ID('dbo.SP_LabSonucCRUD','P') IS NOT NULL DROP PROCEDURE dbo.SP_LabSonucCRUD;
IF OBJECT_ID('dbo.SP_HastaLabSonuclariListele','P') IS NOT NULL DROP PROCEDURE dbo.SP_HastaLabSonuclariListele;
IF OBJECT_ID('dbo.SP_DoktorHastaLabSonuclariListele','P') IS NOT NULL DROP PROCEDURE dbo.SP_DoktorHastaLabSonuclariListele;
IF OBJECT_ID('dbo.SP_RandevuIptalEt','P') IS NOT NULL DROP PROCEDURE dbo.SP_RandevuIptalEt; -- YENİ

-- View 
IF OBJECT_ID('dbo.V_AktifRandevuDetaylari','V') IS NOT NULL DROP VIEW dbo.V_AktifRandevuDetaylari;

-- Fonksiyonlar 
IF OBJECT_ID('dbo.FN_YasHesapla','FN') IS NOT NULL DROP FUNCTION dbo.FN_YasHesapla;
IF OBJECT_ID('dbo.FN_DoktorRandevuSayisi','FN') IS NOT NULL DROP FUNCTION dbo.FN_DoktorRandevuSayisi;
IF OBJECT_ID('dbo.FN_HastaTamAd','FN') IS NOT NULL DROP FUNCTION dbo.FN_HastaTamAd;

-- Log Tabloları
IF OBJECT_ID('dbo.SifreDegisiklikLog','U') IS NOT NULL DROP TABLE dbo.SifreDegisiklikLog;

-- Drop tablolar child -> parent
IF OBJECT_ID('dbo.MuayeneKayitlari','U') IS NOT NULL DROP TABLE dbo.MuayeneKayitlari;
IF OBJECT_ID('dbo.LabSonuclari','U') IS NOT NULL DROP TABLE dbo.LabSonuclari;
IF OBJECT_ID('dbo.RandevuGecmis','U') IS NOT NULL DROP TABLE dbo.RandevuGecmis;
IF OBJECT_ID('dbo.Randevular','U') IS NOT NULL DROP TABLE dbo.Randevular;
IF OBJECT_ID('dbo.Sekreterler','U') IS NOT NULL DROP TABLE dbo.Sekreterler;
IF OBJECT_ID('dbo.Hastalar','U') IS NOT NULL DROP TABLE dbo.Hastalar;
IF OBJECT_ID('dbo.Doktorlar','U') IS NOT NULL DROP TABLE dbo.Doktorlar;
IF OBJECT_ID('dbo.Kullanicilar','U') IS NOT NULL DROP TABLE dbo.Kullanicilar;
GO

----------------------------------------------------------------------------------------------------
-- 2) TABLOLAR
----------------------------------------------------------------------------------------------------

CREATE TABLE Kullanicilar (
    KullaniciID INT IDENTITY(1,1) PRIMARY KEY,
    Ad NVARCHAR(50),
    Soyad NVARCHAR(50),
    TC NVARCHAR(11) UNIQUE,
    Sifre NVARCHAR(64),
    Rol NVARCHAR(20)
);

CREATE TABLE Hastalar (
    HastaID INT IDENTITY(1,1) PRIMARY KEY,
    KullaniciID INT NOT NULL,
    DogumTarihi DATE,
    Telefon NVARCHAR(20),
    Cinsiyet NVARCHAR(10)
);

CREATE TABLE Doktorlar (
    DoktorID INT IDENTITY(1,1) PRIMARY KEY,
    KullaniciID INT NOT NULL,
    Brans NVARCHAR(50)
);

CREATE TABLE Randevular (
    RandevuID INT IDENTITY(1,1) PRIMARY KEY,
    HastaID INT NOT NULL,
    DoktorID INT NOT NULL,
    Tarih DATE,
    Saat TIME,
    Durum NVARCHAR(20)
);

CREATE TABLE LabSonuclari (
    LabID INT IDENTITY(1,1) PRIMARY KEY,
    HastaID INT NOT NULL,
    RandevuID INT NOT NULL,
    TestAdi NVARCHAR(100),
    Sonuc NVARCHAR(100),
    Tarih DATETIME
);

CREATE TABLE MuayeneKayitlari (
    MuayeneID INT IDENTITY(1,1) PRIMARY KEY,
    RandevuID INT UNIQUE,
    DoktorID INT NOT NULL,
    HastaID INT NOT NULL,
    Tani NVARCHAR(250),
    Tedavi NVARCHAR(MAX),
    Recete NVARCHAR(MAX),
    MuayeneTarihi DATETIME DEFAULT GETDATE()
);

CREATE TABLE RandevuGecmis (
    GecmisID INT IDENTITY(1,1) PRIMARY KEY,
    RandevuID INT,
    HastaID INT,
    DoktorID INT,
    IptalTarihi DATETIME DEFAULT GETDATE(),
    IptalEden NVARCHAR(50) DEFAULT 'Sistem',
    Notlar NVARCHAR(500) NULL
);

CREATE TABLE Sekreterler (
    SekreterID INT IDENTITY(1,1) PRIMARY KEY,
    KullaniciID INT NOT NULL
);

-- Log Tablosu (Trigger için gerekli)
CREATE TABLE dbo.SifreDegisiklikLog (
    LogID INT IDENTITY(1,1) PRIMARY KEY,
    KullaniciID INT,
    EskiSifreHash NVARCHAR(64), 
    DegisiklikTarihi DATETIME DEFAULT GETDATE()
);
GO

----------------------------------------------------------------------------------------------------
-- 3) FOREIGN KEY'LER
----------------------------------------------------------------------------------------------------

ALTER TABLE Hastalar ADD CONSTRAINT FK_Hastalar_Kullanicilar FOREIGN KEY (KullaniciID) REFERENCES Kullanicilar(KullaniciID) ON DELETE CASCADE;
ALTER TABLE Doktorlar ADD CONSTRAINT FK_Doktorlar_Kullanicilar FOREIGN KEY (KullaniciID) REFERENCES Kullanicilar(KullaniciID) ON DELETE CASCADE;
ALTER TABLE Randevular ADD CONSTRAINT FK_Randevular_Hastalar FOREIGN KEY (HastaID) REFERENCES Hastalar(HastaID);
ALTER TABLE Randevular ADD CONSTRAINT FK_Randevular_Doktorlar FOREIGN KEY (DoktorID) REFERENCES Doktorlar(DoktorID);
ALTER TABLE LabSonuclari ADD CONSTRAINT FK_Lab_Hastalar FOREIGN KEY (HastaID) REFERENCES Hastalar(HastaID);
ALTER TABLE LabSonuclari ADD CONSTRAINT FK_Lab_Randevular FOREIGN KEY (RandevuID) REFERENCES Randevular(RandevuID);
ALTER TABLE MuayeneKayitlari ADD CONSTRAINT FK_Muayene_Randevu FOREIGN KEY (RandevuID) REFERENCES Randevular(RandevuID);
ALTER TABLE MuayeneKayitlari ADD CONSTRAINT FK_Muayene_Doktor FOREIGN KEY (DoktorID) REFERENCES Doktorlar(DoktorID);
ALTER TABLE MuayeneKayitlari ADD CONSTRAINT FK_Muayene_Hasta FOREIGN KEY (HastaID) REFERENCES Hastalar(HastaID);
ALTER TABLE RandevuGecmis ADD CONSTRAINT FK_RandevuGecmis_Randevular FOREIGN KEY (RandevuID) REFERENCES Randevular(RandevuID);
ALTER TABLE RandevuGecmis ADD CONSTRAINT FK_RandevuGecmis_Hastalar FOREIGN KEY (HastaID) REFERENCES Hastalar(HastaID);
ALTER TABLE RandevuGecmis ADD CONSTRAINT FK_RandevuGecmis_Doktorlar FOREIGN KEY (DoktorID) REFERENCES Doktorlar(DoktorID);
ALTER TABLE Sekreterler ADD CONSTRAINT FK_Sekreterler_Kullanicilar FOREIGN KEY (KullaniciID) REFERENCES Kullanicilar(KullaniciID) ON DELETE CASCADE;
GO

----------------------------------------------------------------------------------------------------
-- 4) STORED PROCEDURE'LER (SP)
----------------------------------------------------------------------------------------------------

-- SP 1: Randevu Ekle Kontrol (Mevcut)
CREATE PROCEDURE dbo.SP_RandevuEkleKontrol
    @HastaID INT,
    @DoktorID INT,
    @Tarih DATE,
    @Saat TIME
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS(SELECT 1 FROM Randevular WHERE DoktorID=@DoktorID AND Tarih=@Tarih AND Saat=@Saat)
    BEGIN
        RAISERROR('Seçilen saat dolu, başka saat seçiniz.',16,1);
        RETURN;
    END

    INSERT INTO Randevular (HastaID,DoktorID,Tarih,Saat,Durum)
    VALUES (@HastaID,@DoktorID,@Tarih,@Saat,'Beklemede');
END;
GO

-- SP 2: Lab Personeli için LabSonuc Ekle/Güncelle/Sil/Listele (CRUD)
CREATE PROCEDURE dbo.SP_LabSonucCRUD
    @IslemTipi CHAR(1), -- 'Insert, 'Update, 'Delete, 'Listele
    @LabID INT = NULL,
    @HastaID INT = NULL,
    @RandevuID INT = NULL,
    @TestAdi NVARCHAR(100) = NULL,
    @Sonuc NVARCHAR(100) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    
    IF @IslemTipi = 'I'
    BEGIN
        IF @HastaID IS NULL OR @RandevuID IS NULL OR @TestAdi IS NULL OR @Sonuc IS NULL
        BEGIN
            RAISERROR('Yeni kayıt için tüm alanlar zorunludur.', 16, 1); RETURN;
        END
        INSERT INTO LabSonuclari (HastaID, RandevuID, TestAdi, Sonuc, Tarih)
        VALUES (@HastaID, @RandevuID, @TestAdi, @Sonuc, GETDATE());
    END
    ELSE IF @IslemTipi = 'U'
    BEGIN
        IF @LabID IS NULL BEGIN RAISERROR('Güncelleme için LabID zorunludur.', 16, 1); RETURN; END
        UPDATE LabSonuclari
        SET TestAdi = ISNULL(@TestAdi, TestAdi), Sonuc = ISNULL(@Sonuc, Sonuc), Tarih = GETDATE()
        WHERE LabID = @LabID;
    END
    ELSE IF @IslemTipi = 'D'
    BEGIN
        IF @LabID IS NULL BEGIN RAISERROR('Silme için LabID zorunludur.', 16, 1); RETURN; END
        DELETE FROM LabSonuclari WHERE LabID = @LabID;
    END
    ELSE IF @IslemTipi = 'L'
    BEGIN
        IF @HastaID IS NULL BEGIN RAISERROR('Listeleme için HastaID zorunludur.', 16, 1); RETURN; END
        SELECT LabID, TestAdi, Sonuc, Tarih
        FROM LabSonuclari
        WHERE HastaID = @HastaID
        ORDER BY Tarih DESC;
    END
    ELSE
    BEGIN
        RAISERROR('Geçersiz İşlem Tipi.', 16, 1); RETURN;
    END
END;
GO

-- SP 3: Hasta için Lab Sonuçlarını Listele 
CREATE PROCEDURE dbo.SP_HastaLabSonuclariListele
    @HastaKullaniciTC NVARCHAR(11)
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @HastaID INT;
    SELECT @HastaID = H.HastaID
    FROM Hastalar H INNER JOIN Kullanicilar K ON H.KullaniciID = K.KullaniciID
    WHERE K.TC = @HastaKullaniciTC AND K.Rol = 'Hasta';

    SELECT LS.LabID, LS.TestAdi, LS.Sonuc, LS.Tarih
    FROM LabSonuclari LS
    WHERE LS.HastaID = @HastaID
    ORDER BY LS.Tarih DESC;
END;
GO

-- SP 4: DOKTOR İÇİN HASTA LAB SONUÇLARINI LİSTELE
CREATE PROCEDURE dbo.SP_DoktorHastaLabSonuclariListele
    @HastaID INT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT
        K.Ad, K.Soyad, LS.TestAdi, LS.Sonuc, LS.Tarih
    FROM LabSonuclari LS
    INNER JOIN Hastalar H ON LS.HastaID = H.HastaID
    INNER JOIN Kullanicilar K ON H.KullaniciID = K.KullaniciID
    WHERE LS.HastaID = @HastaID
    ORDER BY LS.Tarih DESC;
END;
GO

-- SP 5: Randevu İptal Et ve Geçmişe Kaydet 
CREATE PROCEDURE dbo.SP_RandevuIptalEt
    @RandevuID INT,
    @IptalEdenKullaniciID INT, 
    @Notlar NVARCHAR(500) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @IptalEdenAd NVARCHAR(100);
    DECLARE @HastaID INT, @DoktorID INT;

    
    SELECT @IptalEdenAd = Ad + ' ' + Soyad 
    FROM Kullanicilar 
    WHERE KullaniciID = @IptalEdenKullaniciID;

    IF @IptalEdenAd IS NULL BEGIN SET @IptalEdenAd = 'Bilinmeyen Kullanıcı'; END

    SELECT @HastaID = HastaID, @DoktorID = DoktorID
    FROM Randevular
    WHERE RandevuID = @RandevuID;

    IF @HastaID IS NULL BEGIN RAISERROR('Geçersiz Randevu ID.', 16, 1); RETURN; END

    
    INSERT INTO RandevuGecmis (RandevuID, HastaID, DoktorID, IptalTarihi, IptalEden, Notlar)
    VALUES (@RandevuID, @HastaID, @DoktorID, GETDATE(), @IptalEdenAd, ISNULL(@Notlar, 'Randevu iptal edildi.'));

    
    DELETE FROM Randevular
    WHERE RandevuID = @RandevuID;

END;
GO

----------------------------------------------------------------------------------------------------
-- 5) TRIGGER'LAR (TRG) --
----------------------------------------------------------------------------------------------------

-- TRG 1: 
CREATE TRIGGER TRG_LabSonucuGirildi
ON LabSonuclari
AFTER INSERT
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE R
    SET Durum = 'Lab Sonucu Girildi'
    FROM Randevular R
    INNER JOIN inserted I ON R.RandevuID = I.RandevuID;
END;
GO

-- TRG 2: Kullanici şifre değişikliklerini logla 
CREATE TRIGGER TRG_KullaniciSifreDegisiklikLog
ON Kullanicilar
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    IF UPDATE(Sifre)
    BEGIN
        INSERT INTO SifreDegisiklikLog (KullaniciID, EskiSifreHash)
        SELECT D.KullaniciID, D.Sifre 
        FROM deleted D
        INNER JOIN inserted I ON D.KullaniciID = I.KullaniciID
        WHERE D.Sifre <> I.Sifre; 
    END
END;
GO

-- TRG 3: Muayene Kaydı girilmeden önce Randevu Tarihi Kontrol
CREATE TRIGGER TRG_MuayeneKayitlari_RandevuTarihKontrol
ON MuayeneKayitlari
INSTEAD OF INSERT
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS (
        SELECT 1
        FROM inserted I
        INNER JOIN Randevular R ON I.RandevuID = R.RandevuID
        WHERE R.Tarih > CAST(GETDATE() AS DATE) 
    )
    BEGIN
        RAISERROR('Gelecek tarihe ait randevuya muayene kaydı girilemez.', 16, 1);
        ROLLBACK TRANSACTION;
        RETURN;
    END

    -- Kontrolü geçen kayıtları INSERT et
    INSERT INTO MuayeneKayitlari (RandevuID, DoktorID, HastaID, Tani, Tedavi, Recete, MuayeneTarihi)
    SELECT RandevuID, DoktorID, HastaID, Tani, Tedavi, Recete, MuayeneTarihi
    FROM inserted;
END;
GO

-- TRG 4: Hastalar Tablosunda Cinsiyet Formatla
CREATE TRIGGER TRG_Hasta_CinsiyetFormatla
ON Hastalar
INSTEAD OF INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    
    -- Yeni Cinsiyet Değerini Formatlama Fonksiyonu
    DECLARE @YeniCinsiyet TABLE (HastaID INT NULL, KullaniciID INT, DogumTarihi DATE, Telefon NVARCHAR(20), Cinsiyet NVARCHAR(10));
    
    INSERT INTO @YeniCinsiyet (HastaID, KullaniciID, DogumTarihi, Telefon, Cinsiyet)
    SELECT 
        I.HastaID, I.KullaniciID, I.DogumTarihi, I.Telefon,
        CASE 
            WHEN I.Cinsiyet IS NULL THEN 'Belirtilmedi'
            WHEN UPPER(SUBSTRING(I.Cinsiyet, 1, 1)) = 'K' THEN 'Kadin'
            WHEN UPPER(SUBSTRING(I.Cinsiyet, 1, 1)) = 'E' THEN 'Erkek'
            ELSE 'Belirtilmedi'
        END
    FROM inserted I;

    -- INSERT işlemi
    IF EXISTS (SELECT * FROM inserted) AND NOT EXISTS (SELECT * FROM deleted)
    BEGIN
        INSERT INTO Hastalar (KullaniciID, DogumTarihi, Telefon, Cinsiyet)
        SELECT KullaniciID, DogumTarihi, Telefon, Cinsiyet
        FROM @YeniCinsiyet;
    END
    -- UPDATE işlemi
    ELSE IF EXISTS (SELECT * FROM inserted) AND EXISTS (SELECT * FROM deleted)
    BEGIN
        UPDATE H
        SET DogumTarihi = Y.DogumTarihi,
            Telefon = Y.Telefon,
            Cinsiyet = Y.Cinsiyet 
        FROM Hastalar H
        INNER JOIN @YeniCinsiyet Y ON H.HastaID = Y.HastaID;
    END
END;
GO

----------------------------------------------------------------------------------------------------
-- 6) VIEW 
----------------------------------------------------------------------------------------------------

-- VIEW 1: Aktif Randevuların Detaylı Görünümü
CREATE VIEW dbo.V_AktifRandevuDetaylari
AS
SELECT
    R.RandevuID,
    R.Tarih,
    R.Saat,
    R.Durum,
    H_K.Ad AS HastaAdi,
    H_K.Soyad AS HastaSoyadi,
    D_K.Ad AS DoktorAdi,
    D_K.Soyad AS DoktorSoyadi,
    D.Brans
FROM Randevular R
INNER JOIN Hastalar H ON R.HastaID = H.HastaID
INNER JOIN Kullanicilar H_K ON H.KullaniciID = H_K.KullaniciID
INNER JOIN Doktorlar D ON R.DoktorID = D.DoktorID
INNER JOIN Kullanicilar D_K ON D.KullaniciID = D_K.KullaniciID
WHERE R.Durum = 'Beklemede' OR R.Durum = 'Lab Sonucu Girildi'; 
GO

----------------------------------------------------------------------------------------------------
-- 7) FONKSİYONLAR (FN) - 
----------------------------------------------------------------------------------------------------

-- FN 1: Yaş Hesaplama (Skalar Fonksiyon)
CREATE FUNCTION dbo.FN_YasHesapla (@DogumTarihi DATE)
RETURNS INT
AS
BEGIN
    DECLARE @Yas INT;

    SELECT @Yas = DATEDIFF(year, @DogumTarihi, GETDATE()) -
                  CASE WHEN DATEADD(year, DATEDIFF(year, @DogumTarihi, GETDATE()), @DogumTarihi) > GETDATE() THEN 1 ELSE 0 END;

    RETURN @Yas;
END;
GO

-- FN 2: Doktorun Belirli Tarihteki Randevu Sayısını Hesaplama 
CREATE FUNCTION dbo.FN_DoktorRandevuSayisi (@DoktorKullaniciID INT, @Tarih DATE)
RETURNS INT
AS
BEGIN
    DECLARE @Sayi INT;

    SELECT @Sayi = COUNT(R.RandevuID)
    FROM Randevular R
    INNER JOIN Doktorlar D ON R.DoktorID = D.DoktorID
    WHERE D.KullaniciID = @DoktorKullaniciID
      AND R.Tarih = @Tarih
      AND R.Durum <> 'Iptal Edildi';

    RETURN @Sayi;
END;
GO

-- FN 3: Hasta Tam Adını Döndürme
CREATE FUNCTION dbo.FN_HastaTamAd (@HastaID INT)
RETURNS NVARCHAR(101)
AS
BEGIN
    DECLARE @TamAd NVARCHAR(101);

    SELECT @TamAd = K.Ad + ' ' + K.Soyad
    FROM Hastalar H
    INNER JOIN Kullanicilar K ON H.KullaniciID = K.KullaniciID
    WHERE H.HastaID = @HastaID;

    RETURN ISNULL(@TamAd, 'Hasta Bulunamadı');
END;
GO

----------------------------------------------------------------------------------------------------
-- 8) TEST VERİLERİ
----------------------------------------------------------------------------------------------------

-- Kullanıcılar
INSERT INTO Kullanicilar (Ad,Soyad,TC,Sifre,Rol) VALUES
('Zeynep','Saglam','11111111118','12345','Hasta'), -- KULID: 1
('Ahmet','Yucel','22222222222','12345','Hasta'), -- KULID: 2
('Deniz','Celik','33333333333','12345','Hasta'), -- KULID: 3
('Mehmet','Demir','11111111112','12345','Doktor'), -- KULID: 4 (DOKID: 1)
('Ayse','Kara','11111111113','12345','Doktor'), -- KULID: 5 (DOKID: 2)
('Burak','Yildiz','11111111114','12345','Doktor'), -- KULID: 6 (DOKID: 3)
('Ali','Yilmaz','11111111111','12345','Doktor'), -- KULID: 7 (DOKID: 4)
('Lab','Personel','99999999999','12345','Lab'), -- KULID: 8
('Sekreter','A','88888888888','12345','Sekreter'); -- KULID: 9

-- Hastalar (TRG_Hasta_CinsiyetFormatla testi için küçük harf girildi)
INSERT INTO Hastalar (KullaniciID,DogumTarihi,Telefon,Cinsiyet) VALUES
(1,'2003-04-15','05551234567','k'), -- HASTAID: 1 (Cinsiyet: Kadin olmalı)
(2,'1995-07-20','05301112233','e'), -- HASTAID: 2 (Cinsiyet: Erkek olmalı)
(3,'1988-11-05','05404445566','Kadin'); -- HASTAID: 3

-- Doktorlar
INSERT INTO Doktorlar (KullaniciID,Brans) VALUES
(4,'Dahiliye'), -- DOKID: 1 (Mehmet Demir)
(5,'Goz Hastaliklari'), -- DOKID: 2 (Ayşe Kara)
(6,'Noroloji'), -- DOKID: 3 (Burak Yıldız)
(7,'Ortopedi'); -- DOKID: 4 (Ali Yılmaz)

-- Sekreterler
INSERT INTO Sekreterler (KullaniciID) VALUES (9);

-- Randevular
INSERT INTO Randevular (HastaID,DoktorID,Tarih,Saat,Durum) VALUES
(1,1,CAST(GETDATE() AS DATE),'09:00','Beklemede'), -- RNDID 1
(2,1,CAST(GETDATE() AS DATE),'10:00','Beklemede'), -- RNDID 2
(3,2,CAST(GETDATE() AS DATE),'11:00','Beklemede'), -- RNDID 3
(1,3,CAST(GETDATE() AS DATE),'12:00','Beklemede'), -- RNDID 4
(2,4,DATEADD(DAY, 1, CAST(GETDATE() AS DATE)),'14:00','Beklemede'); -- RNDID 5 (Gelecek tarihli)

-- Lab Sonuçları 
INSERT INTO LabSonuclari (HastaID,RandevuID,TestAdi,Sonuc,Tarih) VALUES
(1,1,'Dahiliye Kan Tahlili','Normal',GETDATE()), 
(2,2,'Dahiliye Tahlil 2','Yuksek',GETDATE()),
(3,3,'Goz Muayenesi Sonucu','Miyopi',GETDATE()), -- RNDID 3'ün durumu 'Lab Sonucu Girildi' olacak
(1,4,'EEG Sonucu','Normal',GETDATE()); 

-- Muayene Kayitlari
INSERT INTO MuayeneKayitlari (RandevuID,DoktorID,HastaID,Tani,Tedavi,Recete,MuayeneTarihi) VALUES
(1,1,1,'Üst solunum yolu enfeksiyonu','Istirahat + Sıvı + Antipiretik','Paracetamol 500mg',GETDATE()),
(2,1,2,'Bel ağrısı','Istirahat + Egzersiz','İbuprofen 200mg',GETDATE());
GO

-- DB Multi User
ALTER DATABASE HastaneOtomasyon SET MULTI_USER;
GO

PRINT '✅ Veritabanı Yapılandırması Tamamlandı. Tüm Proje Nesneleri Entegre Edildi.';
GO

